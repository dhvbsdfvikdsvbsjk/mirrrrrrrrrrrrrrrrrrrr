﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mirk
{
    public partial class remont : Form
    {
        public remont()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "mirDataSet.computers". При необходимости она может быть перемещена или удалена.
            this.computersTableAdapter.Fill(this.mirDataSet.computers);
            label2.Text = iro.rle;
            label9.Text = iro.rle;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Menu f = new Menu();
            f.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
