﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mirk
{
    public partial class auto1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=K312_HP600_3;Initial Catalog=mir;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();
        public auto1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select CONCAT(familia,name,surname) as familia from eqyz where login = '" + textBox1.Text + "' and pass = '" + textBox2.Text + "'");
            cmd.Connection = con;
            con.Open();
            var res = cmd.ExecuteScalar().ToString();
            con.Close();
            iro.rle = res;
            MessageBox.Show(res);
            cmd = new SqlCommand("select role from eqyz where login = '" + textBox1.Text + "' and pass = '" + textBox2.Text + "'");
            cmd.Connection = con;
            con.Open();
            var resu = cmd.ExecuteScalar().ToString();
            con.Close();
            iro.elr = resu;
            MessageBox.Show(resu);
            /*if (resu == "Директор  ")
            {
                sotri f = new sotri();
                f.Show();
                Hide();
            }
            else if (resu == "Сборщик   ")
            {
                comtech f = new comtech();
                f.Show();
                Hide();
            }
            else if (resu == "Менеджер  ")
            {
                remont f = new remont();
                f.Show();
                Hide();
            }
            else if (resu == "Админ     ")
            {
                otchet f = new otchet();
                f.Show();
                Hide();
            }
            else
            {
                MessageBox.Show("У пользователя нет роли");
            }*/
            Menu f = new Menu();
            f.Show();
            Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
