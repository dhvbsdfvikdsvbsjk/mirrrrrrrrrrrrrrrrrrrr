﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mirk
{
    public static class iro
    {
        public static string rle;
        public static string elr;
    }
}
