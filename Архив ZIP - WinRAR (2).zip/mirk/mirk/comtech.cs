﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mirk
{
    public partial class comtech : Form
    {
        SqlConnection con = new SqlConnection("Data Source=K312_HP600_3;Initial Catalog=mir;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();
        public comtech()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            label2.Text = iro.rle;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("INSERT INTO[dbo].[computers] ([marki],[comptex],[tiptex],[xapaktepictiki]) VALUES(" +
                "'"+textBox1.Text+"'" +
                ",'"+textBox2.Text+"'," +
                "'"+textBox3.Text+"'," +
                "'"+textBox4.Text+"')");
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Добавлены данные");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Menu f = new Menu();
            f.Show();
            Hide();
        }
    }
}
