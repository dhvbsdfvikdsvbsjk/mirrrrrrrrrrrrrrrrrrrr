﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mirk
{
    public partial class sotri : Form
    {
        SqlConnection con = new SqlConnection("Data Source=K312_HP600_3;Initial Catalog=mir;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();
        string imglocation = "";
        public sotri()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label2.Text = iro.rle;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "all filles(*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                imglocation = dialog.FileName.ToString();
                pictureBox1.ImageLocation = imglocation;
            }
            int count = 0;
            count++;
            byte[] images = null;
            FileStream stream = new FileStream(imglocation, FileMode.Open, FileAccess.Read);
            BinaryReader brs = new BinaryReader(stream);
            images = brs.ReadBytes((int)stream.Length);
            cmd = new SqlCommand("INSERT INTO [dbo].[soti]([name],[fio],[wasborn],[role],[login],[pass],[photo]) VALUES('"+textBox1.Text+"'" +
                ",'"+textBox2.Text+"','"+dateTimePicker1+"','"+comboBox1.Text+"','"+textBox3.Text+"','"+textBox4.Text+"',@images)");
            cmd.Connection = con;
            con.Open();
            cmd.Parameters.Add(new SqlParameter("@images", images));
            int n = cmd.ExecuteNonQuery();
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Menu f = new Menu();
            f.Show();
            Hide();
        }
    }
}
